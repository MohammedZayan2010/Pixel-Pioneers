
import random

# Sample chemistry questions and answers
chemistry_questions = [
    "What is the chemical symbol for water?",
    "What is the atomic number of oxygen?",
    "What is the formula for sodium chloride?",
    "What is the pH of a neutral solution?",
    "What is Avogadro's number?",
    "What is the chemical formula for ammonia?",
    "What is the SI unit of pressure?",
    "What is the formula for calculating density?",
    "What is the law of conservation of mass?",
    "What is the process by which a liquid changes into a gas at a temperature below its boiling point called?"
]

chemistry_answers = [
    "H2O",
    "8",
    "NaCl",
    "7",
    "6.022 x 10^23",
    "NH3",
    "Pascal",
    "Mass/Volume",
    "Matter cannot be created or destroyed",
    "Evaporation"
]

# Dictionary of chapters related to chemistry questions
chapter_dict = {
    "What is the chemical symbol for water?": "Chemical Bonding",
    "What is the atomic number of oxygen?": "Atomic Structure",
    "What is the formula for sodium chloride?": "Chemical Reactions",
    "What is the pH of a neutral solution?": "Acids and Bases",
    "What is Avogadro's number?": "Moles and Stoichiometry",
    "What is the chemical formula for ammonia?": "Chemical Compounds",
    "What is the SI unit of pressure?": "Gases",
    "What is the formula for calculating density?": "Properties of Matter",
    "What is the law of conservation of mass?": "Chemical Equilibrium",
    "What is the process by which a liquid changes into a gas at a temperature below its boiling point called?": "States of Matter"
}

def generate_test():
    # Randomly select 10 questions
    selected_questions = random.sample(chemistry_questions, 10)

    # Ask questions and get user answers
    user_answers = {}
    for question in selected_questions:
        user_answer = input(f"{question}\nYour answer: ")
        user_answers[question] = user_answer

    # Organize answers into correct and wrong
    correct_answers = []
    wrong_answers = []
    for question, user_answer in user_answers.items():
        if user_answer.lower() == chemistry_answers[chemistry_questions.index(question)].lower():
            correct_answers.append(question)
        else:
            wrong_answers.append(question)

    # Generate study plan
    study_plan = {}
    for question in wrong_answers:
        chapter = chapter_dict[question]
        if chapter in study_plan:
            study_plan[chapter].append(question)
        else:
            study_plan[chapter] = [question]

    return correct_answers, wrong_answers, study_plan

correct_answers, wrong_answers, study_plan = generate_test()

# Display results
print("\nResults:")
print("Correct Answers:")
for question in correct_answers:
    print(question)
print("\nWrong Answers:")
for question in wrong_answers:
    print(question)

# Display study plan
print("\nStudy Plan:")
for chapter, questions in study_plan.items():
    print(f"Chapter: {chapter}")
    print("Review Questions:")
    for q in questions:
        print(f"- {q}")
